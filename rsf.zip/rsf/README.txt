RaidRSF
Random Shell Scanner

README
Do not selling this free rsf tools
Better use this tool on VPS/RDP
PROS
Support big site-list maybe
Low cpu usage (Friendly cpu usage)
Very fast
CONS
Maybe has some bug because this is a first release
HOW TO USE?
Just fill up/settings ur own HQ config on config.txt
Replace ur sites list file to sites.txt
SUGGESTION
If u want suggestion for new update for this tools you can join our telegram channel: @raid_store
Contact me ?
If you found bugs or any issue on this tools feel free to contact me!

Telegram: @soul_kings